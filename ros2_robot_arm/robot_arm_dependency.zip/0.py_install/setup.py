from setuptools import find_packages,setup
setup(
    name = 'Arm_Lib',
    version = '0.0.5',
    author='Yahboom Team',
    packages = find_packages(),
)

# cd py_install
# sudo python3 setup.py install
